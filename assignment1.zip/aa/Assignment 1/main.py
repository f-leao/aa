import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LinearRegression, Ridge, RidgeCV
from sklearn.compose import ColumnTransformer
import time

OUTPUT_DIR = './output/'

 # read the data
data = pd.read_csv('/data/mlNOVA/mlNOVA/X_train.csv')
data.head()

data.columns,
(pd.Index(['t', 'x_1', 'y_1', 'v_x_1', 'v_y_1', 
             'x_2', 'y_2', 'v_x_2', 'v_y_2',
             'x_3', 'y_3', 'v_x_3', 'v_y_3', 'Id'],
dtype='object'),) 

idx = np.hstack((0, data[data.t == 10].index.values + 1)) 
idx.shape, data.t.min(), data.t.max()

k = np.random.randint(idx.shape[0])
print(k)
pltidx = range(idx[k], 257+idx[k])
pltsquare = idx[k]
plt.plot(data.x_1[pltidx], data.y_1[pltidx])
plt.plot(data.x_2[pltidx], data.y_2[pltidx])
plt.plot(data.x_3[pltidx], data.y_3[pltidx])
plt.plot(data.x_1[pltsquare], data.y_1[pltsquare], 's')
plt.plot(data.x_2[pltsquare], data.y_2[pltsquare], 's')
plt.plot(data.x_3[pltsquare], data.y_3[pltsquare], 's')

# split data into training, validation and test sets
def custom_train_test_split(data):
    unique_initials = data.drop_duplicates(subset=['x1', 'y1', 'x2', 'y2', 'x3', 'y3'])
    
    # Split based on unique initial conditions
    train_initials, test_initials = train_test_split(unique_initials, test_size=0.2, random_state=42)
    train_initials, val_initials = train_test_split(train_initials, test_size=0.25, random_state=42)

    # Get corresponding data based on initial conditions
    train_data = data[data.index.isin(train_initials.index)]
    val_data = data[data.index.isin(val_initials.index)]
    test_data = data[data.index.isin(test_initials.index)]
    
    return train_data, val_data, test_data

train_data, val_data, test_data = custom_train_test_split(data)
    


#*###########################################################################*#

def plot_y_yhat(y_val,y_pred, plot_title = "plot"):
    labels = ['x_1','y_1','x_2','y_2','x_3','y_3']
    MAX = 500
    if len(y_val) > MAX:
        idx = np.random.choice(len(y_val),MAX, replace=False)
    else:
        idx = np.arange(len(y_val))
    plt.figure(figsize=(10,10))
    for i in range(6):
        x0 = np.min(y_val[idx,i])
        x1 = np.max(y_val[idx,i])
        plt.subplot(3,2,i+1)
        plt.scatter(y_val[idx,i],y_pred[idx,i])
        plt.xlabel('True '+labels[i])
        plt.ylabel('Predicted '+labels[i])
        plt.plot([x0,x1],[x0,x1],color='red')
        plt.axis('square')
    plt.savefig(OUTPUT_DIR + plot_title +'.pdf')
    plt.show()