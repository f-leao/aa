# -*- coding: utf-8 -*-
"""
Created on Wed Oct 11 20:53:02 2023

@author: mloup
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import PolynomialFeatures
from sklearn.preprocessing import QuantileTransformer
from sklearn.preprocessing import PowerTransformer
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge, RidgeCV
from sklearn.compose import ColumnTransformer
from skl2onnx import to_onnx
import onnxruntime as rt
from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType
import time

###################################################

def read_data(file_name):
    """Read the data in csv files"""
    data = pd.read_csv(file_name)
    return data

###################################################

def prepare_data(data, first_index):
    """Prepare all train data and validation data, without restrictions"""
    idx = np.hstack((first_index, data[data.t == 10].index.values + 1))
    Xs = []
    ys = []

    #for i in range(idx.shape[0] - 1):
    for i in range(int((idx.shape[0] - 1))):
        pos = range(idx[i], 257 + idx[i])
        initial_pos = idx[i]

        X = pd.DataFrame({
            'x_1': data.x_1[initial_pos],
            'y_1': data.y_1[initial_pos],
            'x_2': data.x_2[initial_pos],
            'y_2': data.y_2[initial_pos],
            'x_3': data.x_3[initial_pos],
            'y_3': data.y_3[initial_pos],
            't': data.t[pos]
        })

        y = pd.DataFrame({
            'x_1': data.x_1[pos],
            'y_1': data.y_1[pos],
            'x_2': data.x_2[pos],
            'y_2': data.y_2[pos],
            'x_3': data.x_3[pos],
            'y_3': data.y_3[pos],
            't': data.t[pos]
        })

        Xs.append(X)
        ys.append(y)

    X_final = pd.concat(Xs)
    y_final = pd.concat(ys)
    return X_final, y_final

def prepare_data_without_zeros(data):
    """Prepare all train data and validation data, without zeros"""
    idx = np.hstack((data[data.t == 10].index.values + 1))
    Xs = []
    ys = []

    for i in range(int((idx.shape[0] - 1))):
        pos = range(idx[i] - 257, idx[i])
        initial_pos = idx[i]

        X = pd.DataFrame({
            'x_1': data.x_1[initial_pos],
            'y_1': data.y_1[initial_pos],
            'x_2': data.x_2[initial_pos],
            'y_2': data.y_2[initial_pos],
            'x_3': data.x_3[initial_pos],
            'y_3': data.y_3[initial_pos],
            't': data.t[pos]
        })

        y = pd.DataFrame({
            'x_1': data.x_1[pos],
            'y_1': data.y_1[pos],
            'x_2': data.x_2[pos],
            'y_2': data.y_2[pos],
            'x_3': data.x_3[pos],
            'y_3': data.y_3[pos],
            't': data.t[pos]
        })

        Xs.append(X)
        ys.append(y)

    X_final = pd.concat(Xs)
    y_final = pd.concat(ys)
    return X_final, y_final

################################################### 

def linear_regression(X_train, y_train, X_validation, y_validation):
    """Linear Regression"""
    reg = LinearRegression()
    reg.fit(X_train, y_train)
    y_pred = pd.DataFrame(reg.predict(X_validation))
    print(mean_squared_error(y_validation, y_pred))
    
################################################### 

def compute_best_deg_np(X_train, y_train, X_validation, y_validation, degree):
    best_err = 100000000
    for deg in range(1, degree):
        coefs = np.polyfit(np.concatenate(X_train.values), np.concatenate(y_train.values), deg)
        y_pred = np.polyval(coefs, X_validation)
        valid_err = mean_squared_error(y_validation, y_pred)
        print("-> Validation error {} for degree {}".format(valid_err, deg))
        
        if valid_err < best_err:
            best_err = valid_err
            best_coef = y_pred
            best_deg = deg
    
    print("Best error: {}, best degree {}.".format(best_err, best_deg))
    
def compute_best_deg_pl(X_train, y_train, X_validation, y_validation, X_test, degree):
    best_err = 100000000
    
    
    transf = make_pipeline(QuantileTransformer(n_quantiles=300), PowerTransformer(), StandardScaler())
    for deg in range(4, 5):
        
        polyreg = make_pipeline(transf, PolynomialFeatures(degree=deg, include_bias=False), LinearRegression())
        print(f"1. Pipe created for degree {deg}.")
        
        polyreg.fit(X_train, y_train)
        print("2. Fit made with success.")
        
        """  
        initial_type = [('X', FloatTensorType([None, X_train.shape[1]]))]
        onx = convert_sklearn(polyreg, initial_types=initial_type)
        with open("tbp.onnx", "wb") as f:
            f.write(onx.SerializeToString())
        
        sess = rt.InferenceSession("tbp.onnx", providers=["CPUExecutionProvider"])
        input_name = sess.get_inputs()[0].name
        label_name = sess.get_outputs()[0].name

        pred_onx = sess.run([label_name], {input_name: X_validation.values.astype(np.float32)})[0]
        
    
        valid_err = mean_squared_error(y_validation, pred_onx)
        print("-> onx: Validation error {} for degree {}".format(valid_err, deg))
        """
        
        y_pred = polyreg.predict(X_validation)
        print("Predictions made.")
        
        valid_err = mean_squared_error(y_validation, y_pred)
        print("-> poly: Validation error {} for degree {}".format(valid_err, deg))
        
        """
        y_test = pd.DataFrame(polyreg.predict(X_test))
        y_test = y_test.drop(columns=[6])
        y_test.to_csv('sample_sub_test1.csv', index=True, index_label='Id', header=['x_1', 'y_1', 'x_2', 'y_2', 'x_3', 'y_3']) 
        """
        
        """
        if valid_err < best_err:
            best_err = valid_err
            best_coef = y_pred
            best_deg = deg

    print("Best error: {}, best degree {}.".format(best_err, best_deg))
    """
    
def compute_best_lamb_pl(X_train, y_train, X_validation, y_validation, deg, lamb):
    #best_err = 100000000
    #lambs = np.linspace(0.01, lamb)
    #preprocessor = make_pipeline(QuantileTransformer(n_quantiles=300), PowerTransformer())
    polyreg = make_pipeline(QuantileTransformer(), RidgeCV(alphas=[0.001, 0.01, 0.1, 1, 10, 100], cv=3, scoring='neg_mean_squared_error'))
    polyreg.fit(X_train, y_train)
    best_alpha = polyreg.named_steps['ridgecv'].alpha_
    y_pred = polyreg.predict(X_validation)
    valid_err = mean_squared_error(y_validation, y_pred)
    print("-> Validation error {} for best alpha {}".format(valid_err, best_alpha))

    """
    if valid_err < best_err:
        best_err = valid_err
        best_coef = y_pred
        best_lamb = l
    
    print("Best error: {}, best lambda {}.".format(best_err, best_lamb))
    """
    
###################################################

"""Main"""

train_validation_data = read_data('./X_train.csv')
test_data = read_data('./X_test.csv')

train_data, validation_data = train_test_split(train_validation_data, train_size=0.95, shuffle=False)

X_train, y_train = prepare_data(train_data, 0)
X_validation, y_validation = prepare_data(validation_data, len(train_data))

X_test = pd.DataFrame({
    'x_1': test_data.x0_1,
    'y_1': test_data.y0_1,
    'x_2': test_data.x0_2,
    'y_2': test_data.y0_2,
    'x_3': test_data.x0_3,
    'y_3': test_data.y0_3,
    't': test_data.t
})

#linear_regression(X_train, y_train, X_validation, y_validation)
#compute_best_deg_np(X_train, y_train, X_validation, y_validation, 10)
compute_best_deg_pl(X_train, y_train, X_validation, y_validation, X_test, 6)
#compute_best_lamb_pl(X_train, y_train, X_validation, y_validation, 7, 0.2)

"""
X_test = pd.DataFrame({
    'x_1': test_data.x0_1,
    'y_1': test_data.y0_1,
    'x_2': test_data.x0_2,
    'y_2': test_data.y0_2,
    'x_3': test_data.x0_3,
    'y_3': test_data.y0_3,
    't': test_data.t
})

polyreg = make_pipeline(QuantileTransformer(), PolynomialFeatures(degree=5, include_bias=False), LinearRegression())
polyreg.fit(X_train, y_train)
y_pred = pd.DataFrame(polyreg.predict(X_test))
#print("-> Validation error {}".format(mean_squared_error(y_validation, y_pred)))
      
y_pred = y_pred.drop(columns=[6])
y_pred.to_csv('sample_sub.csv', index=True, index_label='Id', header=['x_1', 'y_1', 'x_2', 'y_2', 'x_3', 'y_3']) 
"""